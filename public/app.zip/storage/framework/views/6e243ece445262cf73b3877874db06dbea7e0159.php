<?php $__env->startSection('tanda'); ?>
<?php if(Auth::user()->role == 'manager'): ?>
<?php echo e(Breadcrumbs::render('invoice',$order)); ?>

<?php else: ?>
<?php echo e(Breadcrumbs::render('invoiceKasir',$order)); ?>

<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('subhead'); ?>
    <title>Invoice</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('subcontent'); ?>
    <div class="intro-y flex flex-col sm:flex-row items-center mt-8">
        <h2 class="text-lg font-medium mr-auto">Invoice Layout</h2>
        
    </div>
    <!-- BEGIN: Invoice -->
    <div class="intro-y box overflow-hidden mt-5">

        <div class="border-b border-gray-200 dark:border-dark-5 text-center sm:text-left">
            <?php $__currentLoopData = $order->unique('code_transaksi'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="px-5 py-10 sm:px-20 sm:py-20">
                <div class="text-theme-1 dark:text-theme-10 font-semibold text-3xl">INVOICE</div>
                <div class="mt-2">
                    Receipt <span class="font-medium">#<?php echo e($item->code_transaksi); ?></span>
                </div>
                <div class="mt-1"><?php echo e(\Carbon\Carbon::parse($item->created_at)->setTimezone('Asia/Jakarta')->isoFormat('D MMMM YYYY ')); ?></div>
            </div>
            <div class="flex flex-col lg:flex-row px-5 sm:px-20 pt-10 pb-10 sm:pb-20">
                <div>
                    <div class="text-base text-gray-600">Customer Details</div>
                    <div class="text-lg font-medium text-theme-1 dark:text-theme-10 mt-2">Nama : <?php echo e($item->customer->name); ?></div>
                    <div class="mt-1">Table : <?php echo e($item->customer->telepon); ?></div>
                    
                </div>
                <div class="lg:text-right mt-10 lg:mt-0 lg:ml-auto">
                    <div class="text-base text-gray-600">Payment Method</div>
                    <?php if($item->jenis_pembayaran == 1): ?>
                    <div class="text-lg font-medium text-theme-1 dark:text-theme-10 mt-2">Cash</div>
                    <?php else: ?>
                    <div class="text-lg font-medium text-theme-1 dark:text-theme-10 mt-2">Transfer</div>
                    <?php endif; ?>
                    
                </div>
            </div>
        </div>
        <div class="px-5 sm:px-16 py-10 sm:py-20">
            <div class="overflow-x-auto">
                <table class="table">
                    <thead>
                        <tr>
                            <th class="border-b-2 dark:border-dark-5 whitespace-nowrap">NAME</th>
                            <th class="border-b-2 dark:border-dark-5 whitespace-nowrap">NOTE</th>

                            <th class="border-b-2 dark:border-dark-5 text-right whitespace-nowrap">QTY</th>
                            <th class="border-b-2 dark:border-dark-5 text-right whitespace-nowrap">PRICE</th>
                            <th class="border-b-2 dark:border-dark-5 text-right whitespace-nowrap">SUBTOTAL</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <td class="border-b dark:border-dark-5">
                                <div class="font-medium whitespace-nowrap"><?php echo e($item->nameMenu->name); ?></div>
                                
                            </td>
                            <td class="border-b dark:border-dark-5">
                                <div class="font-medium whitespace-nowrap"><?php echo e($item->note); ?></div>
                                
                            </td>
                            <td class="text-right border-b dark:border-dark-5 w-32"><?php echo e($item->quantity); ?></td>
                            <td class="text-right border-b dark:border-dark-5 w-32">RP. <?php echo e(number_format($item->harga_satuan)); ?></td>
                            <td class="text-right border-b dark:border-dark-5 w-32 font-medium">RP. <?php echo e(number_format($item->jumlah_harga)); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="px-5 sm:px-20 pb-10 sm:pb-20 flex flex-col-reverse sm:flex-row">
            
            <div class="text-center sm:text-right sm:ml-auto">
                <div class="text-base text-gray-600">Total Amount</div>
                <div class="text-xl text-theme-1 dark:text-theme-10 font-medium mt-2">RP. <?php echo e(number_format($totalAmount)); ?></div>
                
            </div>
        </div>
    </div>
    <!-- END: Invoice -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('../layout/' . $layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/allyakin/public_html/new-inventory/resources/views/pages/manager/catatanTransaksi/invoice.blade.php ENDPATH**/ ?>