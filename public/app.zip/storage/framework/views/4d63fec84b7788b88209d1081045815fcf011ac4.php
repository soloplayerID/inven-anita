<?php $__env->startSection('tanda'); ?>
<?php echo e(Breadcrumbs::render('activity')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('subhead'); ?>
<title>Add New User</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('subcontent'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




<!-- END: Modal CREATED -->
<div class="intro-y flex flex-col sm:flex-row items-center mt-8">
    <h2 class="text-lg font-medium mr-auto">Table Activity Log</h2>
    <div class="w-full sm:w-auto flex mt-4 sm:mt-0">
        
        

    

    </div>
</div>
<!-- BEGIN: HTML Table Data -->
<div class="intro-y box p-5 mt-5">
    <div class="flex flex-col sm:flex-row sm:items-end xl:items-start">
        <form id="tabulator-html-filter-form" class="xl:flex sm:mr-auto">


        </form>
        <div class="flex mt-5 sm:mt-0">


        </div>
    </div>
    <div class="overflow-x-auto scrollbar-hidden">
        <div class="overflow-x-auto">
            <table class="table">
                <thead>
                    <tr>
                        <th class="border border-b-2 dark:border-dark-5 whitespace-nowrap">No</th>
                        <th class="border border-b-2 dark:border-dark-5 whitespace-nowrap">Name User</th>
                        <th class="border border-b-2 dark:border-dark-5 whitespace-nowrap">Deskripsi</th>
                        <th class="border border-b-2 dark:border-dark-5 whitespace-nowrap">Time</th>
                        
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $activity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="hover:bg-gray-200">
                        <td class="border"><?php echo e($loop->iteration); ?></td>
                        <td class="border"><?php echo e($item->userActi->name); ?></td>
                        <td class="border"> <span class=" text-xs btn btn-rounded btn-primary-soft"><?php echo e($item->description); ?></span></td>
                        <td class="border"> <span class=" text-xs btn btn-rounded btn-danger-soft"><?php echo e(Carbon\Carbon::parse($item->created_at)->diffForHumans()); ?></span></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>
    </div>
</div>
<!-- END: HTML Table Data -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('../layout/side-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/allyakin/public_html/new-inventory/resources/views/pages/activityLog/index.blade.php ENDPATH**/ ?>