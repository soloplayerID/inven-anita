<?php $__env->startSection('tanda'); ?>
<?php echo e(Breadcrumbs::render('catatan_transaksi')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('subhead'); ?>
<title>History Order</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('subcontent'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="intro-y flex flex-col sm:flex-row items-center mt-8">
    <h2 class="text-lg font-medium mr-auto">Table History Order</h2>
    <div class="w-full sm:w-auto flex mt-4 sm:mt-0">
        
        <form method="GET" class="flex flex-row items-center">
            <div class="relative w-56 mx-auto">
                <div
                    class="absolute rounded-l w-10 h-full flex items-center justify-center bg-gray-100 border text-gray-600 dark:bg-dark-1 dark:border-dark-4">
                    <i data-feather="calendar" class="w-4 h-4"></i> </div> <input name="filter_tanggal" id="filter_tanggal" data-category="filter_tanggal" data-dependent="filter_tanggal" type="date"
                    class=" form-control pl-12">
            </div>

            <button type="submit" class=" tooltip btn btn-link box shadow-md ml-2 " title="Filter by Tanggal">
                <i class="w-5 h-5" data-feather="filter"></i>
            </button>
        </form>
        <form method="GET" class="flex flex-row items-center">
            <select name="petugas_id" id="petugas_id" class="dropdown-toggle btn btn-link box shadow-md ml-2 filter"
                data-category="petugas_id" data-dependent="petugas_id">
                <option selected disabled>Filter by Petugas</option>
                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <button type="submit" class=" tooltip btn btn-link box shadow-md ml-2 " title="Filter by Petugas">
                <i class="w-5 h-5" data-feather="filter"></i>
            </button>
        </form>

        <a href="<?php echo e(route('catatan.index')); ?>" class="tooltip btn btn-link box shadow-md ml-10" title="Reset All Filter">
            <i class="w-5 h-5" data-feather="refresh-cw"></i>
        </a>
        
        <a href="<?php echo e(route('laporan')); ?>" target="_blank" class="tooltip btn btn-primary shadow-md ml-2 mr-2"
            title="Laporan Transaksi Hari Ini">
            <i class="w-4 h-4" data-feather="printer"></i>
        </a>
        <a href="<?php echo e(route('pendapatanBulanIni')); ?>" target="_blank" class="tooltip btn btn-primary-soft shadow-md "
            title="Laporan Transaksi Bulan Ini">
            <i class="w-4 h-4" data-feather="printer"></i>
        </a>


    </div>
</div>
<!-- BEGIN: HTML Table Data -->
<div class="intro-y box p-5 mt-5">
    <div class="flex flex-col sm:flex-row sm:items-end xl:items-start">
        <form id="tabulator-html-filter-form" class="xl:flex sm:mr-auto">


        </form>
        <div class="flex mt-5 sm:mt-0">


        </div>
    </div>
    <div class="overflow-x-auto scrollbar-hidden">
        <div class="overflow-x-auto">
            <table class="table" id="dataTable">
                <thead>
                    <tr>
                        <th class="border border-b-2 dark:border-dark-5 whitespace-nowrap text-center ">No</th>
                        <th class="border border-b-2 dark:border-dark-5 whitespace-nowrap">No Transaksi</th>
                        <th class="border border-b-2 dark:border-dark-5 whitespace-nowrap text-center">Nama Petugas
                        </th>
                        <th class="border border-b-2 dark:border-dark-5 whitespace-nowrap text-center">Nama Customer
                        </th>
                        <th class="border border-b-2 dark:border-dark-5 whitespace-nowrap">Status</th>
                        <th class="border border-b-2 dark:border-dark-5 whitespace-nowrap">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $order->unique('code_transaksi'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-gray-200">
                        <td class="border text-center"><?php echo e($loop->iteration); ?></td>
                        <td class="border"><?php echo e($item->code_transaksi); ?></td>
                        <td class="border"><?php echo e($item->user->name); ?></td>
                        <td class="border"><?php echo e($item->customer->name); ?></td>
                      
                        <td class="border">
                            <?php if($item->status == 'SUCCESS'): ?>
                            <span class=" text-xs btn btn-rounded-success">Success</span>
                            <?php elseif($item->status == 'PENDING'): ?>
                            <span class=" text-xs btn btn-rounded-warning">Pending</span>
                            <?php elseif($item->status == 'CANCEL'): ?>
                            <span class=" text-xs btn btn-rounded-danger">Cancel</span>
                            <?php else: ?>
                            <span class=" text-xs btn btn-rounded-primary">Waiting</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?php echo e(route('invoice',$item->code_transaksi)); ?>"
                                class="tooltip btn bg-blue-300 shadow-md mr-2" title="Detail Infoice">
                                <i class="w-4 h-4 " data-feather="eye"></i>
                            </a>
                        </td>
                        
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr class="hover:bg-gray-200">
                        <td class="border text-center" colspan="5">Data Menu Masih Kosong</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('../layout/side-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/allyakin/public_html/new-inventory/resources/views/pages/manager/catatanTransaksi/index.blade.php ENDPATH**/ ?>