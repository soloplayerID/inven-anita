<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<title>Invoice</title>

		<style>
			.invoice-box {
				max-width: 800px;
				margin: auto;
				padding: 30px;
				border: 1px solid #eee;
				box-shadow: 0 0 10px rgba(0, 0, 0, 0.15);
				font-size: 16px;
				line-height: 24px;
				font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
				color: #555;
			}

			.invoice-box table {
				width: 100%;
				line-height: inherit;
				text-align: left;
			}

			.invoice-box table td {
				padding: 5px;
				vertical-align: top;
			}

			.invoice-box table tr td:nth-child(3) {
				text-align: right;
			}

			.invoice-box table tr.top table td {
				padding-bottom: 20px;
			}

			.invoice-box table tr.top table td.title {
				font-size: 45px;
				line-height: 45px;
				color: #333;
			}

			.invoice-box table tr.information table td {
				padding-bottom: 40px;
			}

			.invoice-box table tr.heading td {
				background: #eee;
				border-bottom: 1px solid #ddd;
				font-weight: bold;
			}

			.invoice-box table tr.details td {
				padding-bottom: 20px;
			}

			.invoice-box table tr.item td {
				border-bottom: 1px solid #eee;
			}

			.invoice-box table tr.item.last td {
				border-bottom: none;
			}

			.invoice-box table tr.total td:nth-child(3) {
				border-top: 2px solid #eee;
				font-weight: bold;
			}

			@media  only screen and (max-width: 600px) {
				.invoice-box table tr.top table td {
					width: 100%;
					display: block;
					text-align: center;
				}

				.invoice-box table tr.information table td {
					width: 100%;
					display: block;
					text-align: center;
				}
			}

			/** RTL **/
			.invoice-box.rtl {
				direction: rtl;
				font-family: Tahoma, 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
			}

			.invoice-box.rtl table {
				text-align: right;
			}

			.invoice-box.rtl table tr td:nth-child(3) {
				text-align: left;
			}
		</style>
	</head>

	<body>
		<?php
			$setting = \App\Models\Setting::find(1);
		?>
		<div class="invoice-box">
			<table cellpadding="0" cellspacing="0">
				<tr class="top">
					<td colspan="3">
						<table>
							<tr>
								<td class="title">
								
									<?php if($setting->logo == null): ?>
									
									<?php else: ?>
									<img src="<?php echo e(public_path('/fotoSetting/'.$setting->logo)); ?>" style="width: 50%; max-width: 300px" />
									<?php endif; ?>
								</td>
                                <td></td>
                                <?php $__currentLoopData = $order->unique('code_transaksi'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

								<td>
                                    Invoice #: <?php echo e($item->code_transaksi); ?><br />
									Created: <?php echo e(\Carbon\Carbon::now()->setTimezone('Asia/Jakarta')->isoFormat('D MMMM YYYY')); ?><br />
                                    Customer: <?php echo e($item->customer->name); ?><br />
                                    Petugas:<?php echo e($item->user->name); ?>


								</td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tr>
						</table>
					</td>
				</tr>

				

				

				

				<tr class="heading">
					<td>Item</td>
                    <td>Quantity</td>
					<td>Price</td>
				</tr>
                <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

				<tr class="item">
                    <td><?php echo e($item->nameMenu->name); ?></td>
                    <td><?php echo e($item->quantity); ?></td>
					<td>RP. <?php echo e(number_format($item->jumlah_harga)); ?></td>

				</tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				
				</tr>

				<tr class="total">
					<td></td>
                    <td></td>

					<td>Total: RP .<?php echo e(number_format($jumlahHarga)); ?></td>
				</tr>
			</table>
		</div>
	</body>
</html>
<?php /**PATH /home/allyakin/public_html/new-inventory/resources/views/pages/user/history/invoice.blade.php ENDPATH**/ ?>