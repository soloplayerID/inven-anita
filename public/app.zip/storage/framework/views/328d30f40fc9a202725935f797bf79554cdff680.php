
<?php $__env->startSection('tanda'); ?>
<?php echo e(Breadcrumbs::render('dashboard')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('subhead'); ?>
    <title>Dashboard</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('subcontent'); ?>
    <style>
        #chartdiv {
        width: 100%;
        height: 380px;
        }
    </style>
    <div class="grid grid-cols-12 gap-6">
        <div class="col-span-12 xxl:col-span-9">
            <div class="grid grid-cols-12 gap-6">
                <!-- BEGIN: General Report -->
                <div class="col-span-12 mt-8">
                    <div class="intro-y flex items-center h-10">
                        <h2 class="text-lg font-medium truncate mr-5">General Report</h2>
                        <a href="" class="ml-auto flex text-theme-1 dark:text-theme-10">
                            <i data-feather="refresh-ccw" class="w-4 h-4 mr-3"></i> Reload Data
                        </a>
                    </div>
                    <div class="grid grid-cols-12 gap-6 mt-5">
                        <div class="col-span-12 sm:col-span-6 xl:col-span-3 intro-y">
                            <div class="report-box zoom-in">
                                <div class="box p-5">
                                    <div class="flex">
                                        <i data-feather="shopping-cart" class="report-box__icon text-theme-10"></i>
                                        
                                    </div>
                                    <div class="text-3xl font-bold leading-8 mt-6"><?php echo e(number_format($totalItemTerjual)); ?></div>
                                    <div class="text-base text-gray-600 mt-1">Total Item Terjual</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-span-12 sm:col-span-6 xl:col-span-3 intro-y">
                            <div class="report-box zoom-in">
                                <div class="box p-5">
                                    <div class="flex">
                                        <i data-feather="credit-card" class="report-box__icon text-theme-11"></i>
                                        <div class="ml-auto">
                                            
                                        </div>
                                    </div>
                                    <div class="text-3xl font-bold leading-8 mt-6"><?php echo e(number_format($totalOrder)); ?></div>
                                    <div class="text-base text-gray-600 mt-1">Total Order</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-span-12 sm:col-span-6 xl:col-span-3 intro-y">
                            <div class="report-box zoom-in">
                                <div class="box p-5">
                                    <div class="flex">
                                        <i data-feather="monitor" class="report-box__icon text-theme-12"></i>
                                        <div class="ml-auto">
                                            
                                        </div>
                                    </div>
                                    <div class="text-3xl font-bold leading-8 mt-6"><?php echo e(number_format($totalProducts)); ?></div>
                                    <div class="text-base text-gray-600 mt-1">Total Products</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-span-12 sm:col-span-6 xl:col-span-3 intro-y">
                            <div class="report-box zoom-in">
                                <div class="box p-5">
                                    <div class="flex">
                                        <i data-feather="dollar-sign" class="report-box__icon text-theme-9"></i>
                                        <div class="ml-auto">
                                            
                                        </div>
                                    </div>
                                    <div class="text-3 font-bold leading-8 mt-6">RP .<?php echo e(number_format($totalPendapatan)); ?></div>
                                    <div class="text-base text-gray-600 mt-1">Total Pendapatan</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- END: General Report -->

                <!-- END: Sales Report -->
                <!-- BEGIN: Official Store -->
                <div class="col-span-12 xl:col-span-8 mt-6">
                    <div class="intro-y block sm:flex items-center h-10">
                        <h2 class="text-lg font-medium truncate mr-5">Chart Pendapatan</h2>

                    </div>
                    <div class="intro-y box p-5 mt-12 sm:mt-5">
                        <div id="chartdiv"></div>
                    </div>
                </div>
                <!-- END: Official Store -->
                <!-- BEGIN: Weekly Best Sellers -->
                <div class="col-span-12 xl:col-span-4 mt-6">
                    <div class="intro-y flex items-center h-10">
                        <h2 class="text-lg font-medium truncate mr-5">Best Sellers</h2>
                    </div>
                    <div class="mt-5">
                        <?php $__currentLoopData = $bestSeller; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="intro-y">
                                <div class="box px-4 py-4 mb-3 flex items-center zoom-in">
                                    <div class="w-10 h-10 flex-none image-fit rounded-md overflow-hidden">
                                        <img alt="Midone Tailwind HTML Admin Template" src="<?php echo e(asset('/fotoMenu/' . $item->nameMenu->gambar)); ?>">
                                    </div>
                                    <div class="ml-4 mr-auto">
                                        <div class="font-medium"><?php echo e($item->nameMenu->name); ?></div>
                                        <div class="text-gray-600 text-xs mt-0.5"><?php echo e(\Carbon\Carbon::parse($item->nameMenu->created_at)->diffForHumans()); ?></div>
                                    </div>
                                    <div class="py-1 px-2 rounded-full text-xs bg-theme-9 text-white cursor-pointer font-medium"><?php echo e(number_format($item->terjual)); ?> Sales</div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </div>
                </div>
                <!-- END: Weekly Best Sellers -->

                <!-- BEGIN: Weekly Top Products -->
                
                <!-- END: Weekly Top Products -->
            </div>
        </div>

    </div>
    <!-- Styles -->


    <!-- Resources -->
    <script src="https://cdn.amcharts.com/lib/4/core.js"></script>
    <script src="https://cdn.amcharts.com/lib/4/charts.js"></script>
    <script src="https://cdn.amcharts.com/lib/4/themes/animated.js"></script>

    <!-- Chart code -->
    <script>
    am4core.ready(function() {

    // Themes begin
    am4core.useTheme(am4themes_animated);
    am4core.addLicense("ch-custom-attribution");
    // Themes end

    // Create chart instance
    var chart = am4core.create("chartdiv", am4charts.XYChart);
    chart.dataSource.url="<?php echo e(env('APP_URL')); ?>"+"/api/chartPendapatan";
    // Add data


    // Create axes

    var categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
    categoryAxis.dataFields.category = "months";
    categoryAxis.renderer.grid.template.location = 0;
    categoryAxis.renderer.minGridDistance = 30;

    // categoryAxis.renderer.labels.template.adapter.add("pendapatan", function(pendapatan, target) {
    //   if (target.dataItem && target.dataItem.index & 2 == 2) {
    //     return pendapatan + 25;
    //   }
    //   return pendapatan;
    // });
    // var valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
    var valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
    valueAxis.renderer.labels.template.adapter.add("text", function (text) {
        return "Rp. " + text;
    });

    // Create series
    var series = chart.series.push(new am4charts.ColumnSeries());
    series.dataFields.valueY = "pendapatan";
    series.dataFields.categoryX = "months";
    series.name = "pendapatan";
    series.columns.template.tooltipText = "{categoryX}: [bold]RP .{valueY}[/]";
    series.columns.template.fillOpacity = .8;

    var columnTemplate = series.columns.template;
    columnTemplate.strokeWidth = 2;
    columnTemplate.strokeOpacity = 1;

    }); // end am4core.ready()
    </script>

    <!-- HTML -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('../layout/' . $layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/allyakin/public_html/new-inventory/resources/views/pages/dashboard-overview-1.blade.php ENDPATH**/ ?>