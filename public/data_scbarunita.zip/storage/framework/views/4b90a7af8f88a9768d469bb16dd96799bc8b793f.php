
<?php $__env->startSection('tanda'); ?>
<?php echo e(Breadcrumbs::render('settingMidtrans')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('subhead'); ?>
<title>setting Midtrans</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('subcontent'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- END: Modal CREATED -->
<div class="intro-y flex flex-col sm:flex-row items-center mt-8">
    <h2 class="text-lg font-medium mr-auto">Settings Aplication</h2>
    <div class="w-full sm:w-auto flex mt-4 sm:mt-0">
        
        

        </a>


    </div>
</div>
<!-- BEGIN: HTML Table Data -->
<div class="intro-y box p-5 mt-5">
    <div class="flex flex-col sm:flex-row sm:items-end xl:items-start">
        <div class="flex mt-5 sm:mt-0">


        </div>
    </div>
    <div class="overflow-x-auto scrollbar-hidden">
        <div class="overflow-x-auto">
            <form action="<?php echo e(route('updateMidtrans',1)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="col-span-12">
                    <label for="modal-form-1" class="form-label">Midtrans Merchant ID</label>
                    <input name="merchant" id="modal-form-1" type="text" required class="form-control"
                        placeholder="inputkan nama Aplikasi" value="<?php echo e($setting->midtrans_merchat_id); ?>">
                </div>
                <div class="col-span-12 mt-3">
                    <label for="modal-form-1" class="form-label">Midtrans Client Key</label>
                    <input name="client" id="modal-form-1" type="text" required class="form-control"
                        placeholder="inputkan nama Aplikasi" value="<?php echo e($setting->midtrans_client_key); ?>">
                </div>
                <div class="col-span-12 mt-3">
                    <label for="modal-form-1" class="form-label">Midtrans Server Key</label>
                    <input name="server_key" id="modal-form-1" type="text" required class="form-control"
                        placeholder="inputkan nama Aplikasi" value="<?php echo e($setting->midtrans_server_key); ?>">
                </div>
               
               
                <button type="submit" class="btn btn-primary w-20 mt-5 float-right">Chage</button>
                

            </form>
        </div>
    </div>
</div>
<!-- END: HTML Table Data -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('../layout/side-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/allyakin/public_html/new-inventory/resources/views/pages/admin/setting/settingMidtrans.blade.php ENDPATH**/ ?>