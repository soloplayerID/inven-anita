<?php $__env->startSection('tanda'); ?>
<?php echo e(Breadcrumbs::render('historyOrder')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('subhead'); ?>
<title>History Order</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('subcontent'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="intro-y flex flex-col sm:flex-row items-center mt-8">
    <h2 class="text-lg font-medium mr-auto">Table History Order</h2>
    <div class="w-full sm:w-auto flex mt-4 sm:mt-0">
        
        
        <a href="<?php echo e(route('laporanKasir')); ?>" target="_blank"  class="tooltip btn btn-primary shadow-md mr-2" title="Laporan Transaksi Hari Ini">
            <i class="w-4 h-4" data-feather="printer"></i>
        </a>

    </div>
</div>
<!-- BEGIN: HTML Table Data -->
<div class="intro-y box p-5 mt-5">
    <div class="flex flex-col sm:flex-row sm:items-end xl:items-start">
        <form id="tabulator-html-filter-form" class="xl:flex sm:mr-auto">


        </form>
        <div class="flex mt-5 sm:mt-0">


        </div>
    </div>
    <div class="overflow-x-auto scrollbar-hidden">
        <div class="overflow-x-auto">
            <table class="table" id="dataTable">
                <thead>
                    <tr>
                        <th class="border border-b-2 dark:border-dark-5 whitespace-nowrap text-center ">No</th>
                        <th class="border border-b-2 dark:border-dark-5 whitespace-nowrap">No Transaksi</th>
                        
                        
                        <th class="border border-b-2 dark:border-dark-5 whitespace-nowrap">Status</th>
                        <th class="border border-b-2 dark:border-dark-5 whitespace-nowrap">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $order->unique('code_transaksi'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-gray-200">
                        <td class="border text-center"><?php echo e($loop->iteration); ?></td>
                        <td class="border"><?php echo e($item->code_transaksi); ?></td>
                        
                        
                        <td class="border">
                            <?php if($item->status == 'SUCCESS'): ?>
                            <span class=" text-xs btn btn-rounded-success">Success</span>
                            <?php elseif($item->status == 'PENDING'): ?>
                            <span class=" text-xs btn btn-rounded-warning">Pending</span>
                            <?php elseif($item->status == 'CANCEL'): ?>
                            <span class=" text-xs btn btn-rounded-danger">Cancel</span>
                            <?php else: ?>
                            <span class=" text-xs btn btn-rounded-primary">Waiting</span>
                            <?php endif; ?>
                        </td>
                        <td class="border">
                            <?php if($item->status == 'SUCCESS'): ?>
                            <a href="<?php echo e(route('invoice',$item->code_transaksi)); ?>"
                                class="tooltip btn bg-blue-300 shadow-md mr-2" title="Detail Infoice">
                                <i class="w-4 h-4 " data-feather="eye"></i>
                            </a>
                            <a href="<?php echo e(route('cetakInv',$item->code_transaksi)); ?>" target="_blank" class="tooltip btn btn-success-soft shadow-md mr-2"
                                title="Generate Invoice" >
                                <i class="w-4 h-4" data-feather="printer"></i>
                            </a>
                            <?php endif; ?>
                            <?php if($item->jenis_pembayaran == 2): ?>
                            <a href="<?php echo e($item->url_midtrans); ?>" target="_blank" class="tooltip btn bg-blue-300 shadow-md mr-2" title="Bayar">
                                <i class="w-4 h-4 " data-feather="credit-card"></i>
                            </a>
                            <?php endif; ?>
                            <a href="javascript:;" class="tooltip btn btn-danger-soft shadow-md mr-2"
                                title="Delate Transaksi" data-toggle="modal" data-target="#delete-order-<?php echo e($item->id); ?>">
                                <i class="w-4 h-4" data-feather="trash"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr class="hover:bg-gray-200">
                        <td class="border text-center" colspan="5">Data Menu Masih Kosong</td>
                    </tr>
                    <?php endif; ?>



                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deleteorder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<!-- BEGIN: Modal Content -->
<div id="delete-order-<?php echo e($deleteorder->id); ?>" class="modal" data-backdrop="static" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body p-0">
                <div class="p-5 text-center"> <i data-feather="x-circle"
                        class="w-16 h-16 text-theme-6 mx-auto mt-3"></i>
                    <div class="text-3xl mt-5">Are you sure?</div>
                    <div class="text-gray-600 mt-2">Do you really want to delete these records? <br>This process cannot
                        be undone.</div>
                </div>
                <div class="px-5 pb-8 text-center flex items-center justify-center">

                    <button type="button" data-dismiss="modal"
                        class="btn btn-outline-secondary w-24 mr-1">Cancel</button>
                    <form action="<?php echo e(route('destroyCode',$deleteorder->code_transaksi)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-danger w-24"> Hapus </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('../layout/side-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/allyakin/public_html/new-inventory/resources/views/pages/user/history/index.blade.php ENDPATH**/ ?>