<?php $__env->startSection('head'); ?>
<?php echo $__env->yieldContent('subhead'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('../layout/components/mobile-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $setting = \App\Models\Setting::find(1); ?>
<div class="flex">
    <!-- BEGIN: Side Menu -->
    <nav class="side-nav">
        <a href="" class="intro-x flex items-center pl-5 pt-4">
           
            <?php if($setting->logo == null): ?>
                
            <?php else: ?>
            <img style="width: 50px" alt="Midone Tailwind HTML Admin Template" class="w-10" src="<?php echo e(asset('/fotoSetting/' . $setting->logo)); ?>">
            <?php endif; ?>
            <span class="hidden xl:block text-white text-lg ml-1">
                <?php echo e($setting->name_application); ?> <span class="font-medium"></span>
            </span>
        </a>
        <div class="side-nav__devider my-6"></div>
        <ul>
            <?php if(Auth::user()->role == 'manager' || Auth::user()->role == 'admin'): ?>
            <li>
                <a href="/" class="side-menu <?php if(request()->is('/')): ?> side-menu--active <?php endif; ?>">
                    <div class="side-menu__icon">

                        <i data-feather="home"></i>
                    </div>
                    <div class="side-menu__title">
                        Dashboard
                    </div>
                </a>
            </li>
            <?php endif; ?>
            <?php if(Auth::user()->role == 'admin'): ?>
            <li>
                <a href="<?php echo e(route('adduser.index')); ?>"
                    class="side-menu <?php if(request()->is('adduser')): ?> side-menu--active <?php endif; ?>">
                    <div class="side-menu__icon">
                        <i data-feather="user-plus"></i>
                    </div>
                    <div class="side-menu__title">
                        Add User
                    </div>
                </a>
            </li>
            <li>
                <a class="side-menu <?php if(request()->is('setting/*')): ?> side-menu--active <?php endif; ?>">
                    <div class="side-menu__icon">
                        <i data-feather="settings"></i>
                    </div>
                    <div class="side-menu__title">
                        Setting
                        <div class="side-menu__sub-icon">
                            <i data-feather="chevron-down"></i>
                        </div>
                    </div>
                </a>

                <ul class="<?php echo e(request()->is('setting/*') ? 'side-menu__sub-open' : ''); ?>">
                    <li>
                        <a href="<?php echo e(route('settingsAplication.index')); ?>"
                            class="<?php echo e(request()->is('setting/settingAplication/settingsAplication') ? 'side-menu side-menu--active' : 'side-menu'); ?>">
                            <div class="side-menu__icon">
                                <i data-feather="tool"></i>
                            </div>
                            <div class="side-menu__title">
                                Setting Aplikasi
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('settingMidtrans')); ?>"
                            class="<?php echo e(request()->is('setting/settingAplication/settingMidtrans') ? 'side-menu side-menu--active' : 'side-menu'); ?>">
                            <div class="side-menu__icon">
                                <i data-feather="credit-card"></i>
                            </div>
                            <div class="side-menu__title">
                               Setting Midtrans Key
                            </div>
                        </a>
                    </li>
                  

                </ul>
            </li>
            <?php endif; ?>
            <?php if(Auth::user()->role == 'manager'): ?>
            <li>
                <a class="side-menu <?php if(request()->is('product/*')): ?> side-menu--active <?php endif; ?>">
                    <div class="side-menu__icon">
                        <i data-feather="box"></i>
                    </div>
                    <div class="side-menu__title">
                        Master Product
                        <div class="side-menu__sub-icon">
                            <i data-feather="chevron-down"></i>
                        </div>
                    </div>
                </a>

                <ul class="<?php echo e(request()->is('product/*') ? 'side-menu__sub-open' : ''); ?>">
                    <li>
                        <a href="<?php echo e(route('kategori.index')); ?>"
                            class="<?php echo e(request()->is('product/kategoriProduct/kategori') ? 'side-menu side-menu--active' : 'side-menu'); ?>">
                            <div class="side-menu__icon">
                                <i data-feather="database"></i>
                            </div>
                            <div class="side-menu__title">
                                kategori Product
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('menu.index')); ?>"
                            class="<?php echo e(request()->is('product/addProduct/menu') ? 'side-menu side-menu--active' : 'side-menu'); ?>">
                            <div class="side-menu__icon">
                                <i data-feather="log-in"></i>
                            </div>
                            <div class="side-menu__title">
                                Product
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('restock.index')); ?>"
                            class="<?php echo e(request()->is('product/restockProduct/restock') ? 'side-menu side-menu--active' : 'side-menu'); ?>">
                            <div class="side-menu__icon">
                                <i data-feather="log-out"></i>
                            </div>
                            <div class="side-menu__title">
                                Product Masuk
                            </div>
                        </a>
                    </li>

                </ul>
            </li>
            
            <li>
                <a href="<?php echo e(route('supplier.index')); ?>"
                    class="side-menu <?php if(request()->is('supplier/supplier')): ?> side-menu--active <?php endif; ?>">
                    <div class="side-menu__icon">
                        <i data-feather="gift"></i>
                    </div>
                    <div class="side-menu__title">
                        Supplier
                    </div>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('catatan.index')); ?>"
                    class="side-menu <?php if(request()->is('catatan/catatan')): ?> side-menu--active <?php endif; ?>">
                    <div class="side-menu__icon">
                        <i data-feather="clipboard"></i>
                    </div>
                    <div class="side-menu__title">
                        Catatan Transaksi
                    </div>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('indexReport')); ?>"
                    class="side-menu <?php if(request()->is('report')): ?> side-menu--active <?php endif; ?>">
                    <div class="side-menu__icon">
                        <i data-feather="printer"></i>
                    </div>
                    <div class="side-menu__title">
                        Generate Report
                    </div>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('catatanMutation')); ?>"
                    class="side-menu <?php if(request()->is('mutation')): ?> side-menu--active <?php endif; ?>">
                    <div class="side-menu__icon">
                        <i data-feather="printer"></i>
                    </div>
                    <div class="side-menu__title">
                        Mutation Recap
                    </div>
                </a>
            </li>

            <?php endif; ?>
            <?php if(Auth::user()->role == 'manager' || Auth::user()->role == 'admin'): ?>

            <li>
                <a href="<?php echo e(route('activity.index')); ?>"
                    class="side-menu <?php if(request()->is('activity')): ?> side-menu--active <?php endif; ?>">
                    <div class="side-menu__icon">
                        <i data-feather="activity"></i>
                    </div>
                    <div class="side-menu__title">
                        Activity Log
                    </div>
                </a>
            </li>


            <?php endif; ?>
            <?php if(Auth::user()->role == 'kasir'): ?>
            <li>
                <a href="<?php echo e(route('transaksi.index')); ?>"
                    class="side-menu <?php if(request()->is('transaksi')): ?> side-menu--active <?php endif; ?>">
                    <div class="side-menu__icon">
                        <i data-feather="monitor"></i>
                    </div>
                    <div class="side-menu__title">
                        Point Of Sale
                    </div>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('historyOrder')); ?>"
                    class="side-menu <?php if(request()->is('order')): ?> side-menu--active <?php endif; ?>">
                    <div class="side-menu__icon">
                        <i data-feather="refresh-cw"></i>
                    </div>
                    <div class="side-menu__title">
                        History Order
                    </div>
                </a>
            </li>
            <?php endif; ?>

        </ul>

    </nav>
    <!-- END: Side Menu -->
    <!-- BEGIN: Content -->
    <div class="content">
        <?php echo $__env->make('../layout/components/top-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('subcontent'); ?>
    </div>
    <!-- END: Content -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('../layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/allyakin/public_html/new-inventory/resources/views////layout/side-menu.blade.php ENDPATH**/ ?>