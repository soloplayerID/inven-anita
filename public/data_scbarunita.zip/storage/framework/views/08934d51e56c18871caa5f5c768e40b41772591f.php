
<?php $__env->startSection('tanda'); ?>
<?php echo e(Breadcrumbs::render('customer')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('subhead'); ?>
<title>Customer</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('subcontent'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delete): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!-- BEGIN: Modal Content -->
        <div id="delete-user-<?php echo e($delete->id); ?>" class="modal" data-backdrop="static" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-body p-0">
                        <div class="p-5 text-center"> <i data-feather="x-circle"
                                class="w-16 h-16 text-theme-6 mx-auto mt-3"></i>
                            <div class="text-3xl mt-5">Are you sure?</div>
                            <div class="text-gray-600 mt-2">Do you really want to delete these records? <br>This process cannot
                                be undone.</div>
                        </div>
                        <div class="px-5 pb-8 text-center flex items-center justify-center">

                            <button type="button" data-dismiss="modal"
                                class="btn btn-outline-secondary w-24 mr-1">Cancel</button>
                            <form action="<?php echo e(route('customer.destroy',$delete->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-danger w-24"> Hapus </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!-- END: Modal Content -->

<?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <!-- BEGIN: Modal CREATED -->
<div id="edit-<?php echo e($item->id); ?>" data-backdrop="static" class="modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog  modal-lg">
                <div class="modal-content">
            <!-- BEGIN: Modal Header -->
            <div class="modal-header">
                <h2 class="font-medium text-base mr-auto">Edit customer</h2>
            </div> <!-- END: Modal Header -->

            
            <form enctype="multipart/form-data" action="<?php echo e(route('customer.update',$item->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <!-- BEGIN: Modal Body -->
                <div class="modal-body grid grid-cols-12 gap-4 gap-y-3">
                    <div class="col-span-12">
                        <label for="modal-form-1" class="form-label">Fullname</label>
                        <input name="name" id="modal-form-1" type="text" required class="form-control"
                            placeholder="inputkan nama"  value="<?php echo e($item->name); ?>" >

                    </div>
                    <div class="col-span-12">
                        <label for="modal-form-1" class="form-label">Alamat</label>
                        <textarea type="text" class="form-control" required name="alamat"><?php echo e($item->alamat); ?></textarea>

                    </div>
                    <div class="col-span-6">
                        <label for="modal-form-1" class="form-label">Email</label>
                        <input name="email" id="modal-form-1" type="email" value="<?php echo e($item->email); ?>"  class="form-control"
                            placeholder="inputkan Email">

                    </div>
                    <div class="col-span-6">
                        <label for="modal-form-1" class="form-label">Telepon</label>
                        <input name="telepon" id="modal-form-1" type="number"  value="<?php echo e($item->telepon); ?>" required class="form-control"
                            placeholder="inputkan telepon">

                    </div>


                    


                </div> <!-- END: Modal Body -->

                <!-- BEGIN: Modal Footer -->
                <div class="modal-footer text-right">
                    <button type="button" data-dismiss="modal"
                        class="btn btn-outline-secondary w-20 mr-1">Cancel</button>
                    <button type="submit" class="btn btn-primary w-20">Send</button>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- END: Modal CREATED -->
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div id="add" data-backdrop="static" class="modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog  modal-lg">
                <div class="modal-content">
            <!-- BEGIN: Modal Header -->
            <div class="modal-header">
                <h2 class="font-medium text-base mr-auto">Tambah customer</h2>
            </div> <!-- END: Modal Header -->

            
            <form enctype="multipart/form-data" action="<?php echo e(route('customer.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
     
                <!-- BEGIN: Modal Body -->
                <div class="modal-body grid grid-cols-12 gap-4 gap-y-3">
                    <div class="col-span-12">
                        <label for="modal-form-1" class="form-label">Fullname</label>
                        <input name="name" id="modal-form-1" type="text" required class="form-control"
                            placeholder="inputkan nama"   >

                    </div>
                    <div class="col-span-12">
                        <label for="modal-form-1" class="form-label">Alamat</label>
                        <textarea type="text" class="form-control" required name="alamat"></textarea>

                    </div>
                    <div class="col-span-6">
                        <label for="modal-form-1" class="form-label">Email</label>
                        <input name="email" id="modal-form-1" type="email"  class="form-control"
                            placeholder="inputkan Email">

                    </div>
                    <div class="col-span-6">
                        <label for="modal-form-1" class="form-label">Telepon</label>
                        <input name="telepon" id="modal-form-1" type="number"  required class="form-control"
                            placeholder="inputkan telepon">

                    </div>


                    


                </div> <!-- END: Modal Body -->

                <!-- BEGIN: Modal Footer -->
                <div class="modal-footer text-right">
                    <button type="button" data-dismiss="modal"
                        class="btn btn-outline-secondary w-20 mr-1">Cancel</button>
                    <button type="submit" class="btn btn-primary w-20">Send</button>
                </div>
            </form>
        </div>
    </div>
</div>





<div class="intro-y flex flex-col sm:flex-row items-center mt-8">
    <h2 class="text-lg font-medium mr-auto">Table Data Customer</h2>
    <div class="w-full sm:w-auto flex mt-4 sm:mt-0">
        
        

    </a>
        <a href="javascript:;" class="tooltip btn btn-primary shadow-md mr-2" title="Add New Customer" data-toggle="modal"
            data-target="#add">
            <i class="w-4 h-4" data-feather="plus"></i>
        </a>

    </div>
</div>
<!-- BEGIN: HTML Table Data -->
<div class="intro-y box p-5 mt-5">
    <div class="flex flex-col sm:flex-row sm:items-end xl:items-start">
        <form id="tabulator-html-filter-form" class="xl:flex sm:mr-auto">


        </form>
        <div class="flex mt-5 sm:mt-0">


        </div>
    </div>
    <div class="overflow-x-auto scrollbar-hidden">
        <div class="overflow-x-auto">
            <table class="table">
                <thead>
                    <tr>
                        <th class="border border-b-2 dark:border-dark-5 whitespace-nowrap">No</th>
                        <th class="border border-b-2 dark:border-dark-5 whitespace-nowrap">Nama</th>
                        <th class="border border-b-2 dark:border-dark-5 whitespace-nowrap">alamat</th>
                        <th class="border border-b-2 dark:border-dark-5 whitespace-nowrap">email</th>
                        <th class="border border-b-2 dark:border-dark-5 whitespace-nowrap">telepon</th>
                        <th class="border border-b-2 dark:border-dark-5 whitespace-nowrap">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="hover:bg-gray-200">
                        <td class="border"><?php echo e($loop->iteration); ?></td>
                        <td class="border"><?php echo e($item->name); ?></td>
                        <td class="border"><p style="width: 150px"><?php echo e($item->alamat); ?></p></td>
                        <td class="border"><?php echo e($item->email); ?></td>
                        <td class="border"><?php echo e($item->telepon); ?></td>
                        <td class="border">
                            <a href="javascript:;" class="tooltip btn btn-warning-soft shadow-md mr-2"
                                title="Edit Customer" data-toggle="modal" data-target="#edit-<?php echo e($item->id); ?>">
                                <i class="w-4 h-4" data-feather="edit"></i>
                            </a>
                            <a href="javascript:;" class="tooltip btn btn-danger-soft shadow-md mr-2"
                                title="Delete Customer" data-toggle="modal" data-target="#delete-user-<?php echo e($item->id); ?>">
                                <i class="w-4 h-4" data-feather="trash"></i>
                            </a>

                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>
    </div>
</div>
<!-- END: HTML Table Data -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('../layout/side-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/allyakin/public_html/new-inventory/resources/views/pages/manager/customer/index.blade.php ENDPATH**/ ?>