<!-- BEGIN: Dark Mode Switcher-->

<!-- END: Dark Mode Switcher-->
<?php /**PATH /home/allyakin/public_html/new-inventory/resources/views////layout/components/dark-mode-switcher.blade.php ENDPATH**/ ?>